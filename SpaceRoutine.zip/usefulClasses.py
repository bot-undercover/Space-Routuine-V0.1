import json, pygame as pg
from resources.datapack import SPRITES

size = 60
SCREEN_SIZE = (800, 500)


class Map:
    def __init__(self, level="CUSTOM", size=[0, 0]):
        self.mapSprites = pg.sprite.Group()
        if level != "CUSTOM":
            with open("./resources/levels/" + level + ".json") as f:
                level = json.load(f)
                self.map = [[[] for _ in range(level["size"][1])] for _ in range(level["size"][0])]
                for layers in level["levelBackground"]:
                    for x in range(layers[0][0], layers[1][0]):
                        for y in range(layers[0][1], layers[1][1]):
                            self.map[x][y].append(SPRITES[layers[2]].get())

                for level, mapBlocks in level["level"].items():
                    for pos, blocks in mapBlocks.items():
                        x, y = list(map(int, pos.split("/")))
                        for block in blocks:
                            block, rotation = block
                            self.map[x][y].append(SPRITES[block].get(rotation))
        else:
            if 0 not in size:
                self.map = [[None for _ in range(size[1])] for _ in range(size[0])]
            else:
                self.map = None

    def importObject(self, pos, object):
        self.map[pos[0]][pos[1]] = object

    def show(self, screen):
        for x, data in enumerate(self.map):
            for y, blocks in enumerate(data):
                if blocks:
                    for block in blocks:
                        screen.blit(pg.transform.scale(block, (size, size)), (x * size, y * size))


class Player:
    def __init__(self, pos=[0, 0], rotation=0, health=100, oxygen=0, inventory=[], costume=None):
        self.pos, self.health, self.oxygen, self.inventory, self.rotation = pos, health, oxygen, inventory, rotation
        self.costumeUsing = costume
        self.count = 0

    def updateOxygen(self):
        if self.count >= 30:
            if not self.costumeUsing:
                self.oxygen -= 1
            elif self.costumeUsing:
                self.oxygen += 1
            self.count = 0
        if self.costumeUsing != None:
            self.count += 1

    def check(self, data):
        if data[pg.K_w] or data[pg.K_UP]:
            self.pos[1] -= 2
        if data[pg.K_s] or data[pg.K_DOWN]:
            self.pos[1] += 2
        if data[pg.K_a] or data[pg.K_LEFT]:
            self.pos[0] -= 2
        if data[pg.K_d] or data[pg.K_RIGHT]:
            self.pos[0] += 2

    def drawPlayer(self, screen):
        screen.blit(SPRITES["player"].get(self.rotation), (self.pos[0], self.pos[1]))
