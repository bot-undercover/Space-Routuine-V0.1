import pygame as pg

def checkRotation(angle):
    if type(angle) == int:
        return angle
    else:
        if angle.isdigit():
            return int(angle)
        else:
            if angle.lower() == "top":
                return -90
            elif angle.lower() == "left":
                return 180
            elif angle.lower() == "down":
                return 90
            else:
                return 0

class Sprite:
    def __init__(self, path):
        self.sprite = pg.image.load(path)

    def get(self, angle=0):
        return pg.transform.rotate(self.sprite, checkRotation(angle))


class Sprites:
    def __init__(self, paths):
        self.sprites = [pg.image.load(path) for path in paths]
        self.count = 0

    def get(self, angle=0):
        self.count += 1
        if self.count >= len(self.sprites):
            self.count = 0
        return list(map(lambda x: pg.transform.rotate(x, checkRotation(angle)), self.sprites))[self.count - 1]
